<?php
namespace EE\Exceptions;

class OperationNotFoundException extends CalculatorException
{

}