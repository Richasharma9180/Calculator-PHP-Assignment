<?php


namespace EE\Exceptions;

class CalculatorException extends \Exception
{

}