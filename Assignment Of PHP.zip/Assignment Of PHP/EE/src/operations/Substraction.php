<?php
namespace EE\operations;

use EE\operations\OperationInterface;

class Substraction implements OperationInterface
{
    public function isValid(array $numberArray): bool
    {
        // TODO: Implement isValid() method.
    }

    public function execute(array $numberArray): float
    {
        return array_diff($numberArray);
    }
} 